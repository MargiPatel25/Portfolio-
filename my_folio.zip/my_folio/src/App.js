import Banner from "./components/Banner";
import Header from "./components/Header";
import Projects from "./components/Projects";
import Contact from "./components/Contact";
import Avatar from "./components/Avatar";

function App() {
  return (
    <div >
      <Header />
      <Avatar />
      <Banner />
      <Projects />
      <Contact />
      
    
    </div>
  );
}

export default App;
