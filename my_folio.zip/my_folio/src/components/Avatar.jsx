import React from 'react'
import Avatar from "@mui/material/Avatar"
import { alignProperty } from '@mui/material/styles/cssUtils';
import { bgcolor } from '@mui/system';
import { withTheme } from '@emotion/react';
import { red, yellow } from '@mui/material/colors';
import { withStyles } from '@mui/material';


function MuiAvatar() {
  return (
    <Avatar 
    alt="Margi Patel"
    src="/project/personal.jpeg"
    sx={{ width: 100, height: 100, marginLeft:80 }}


    />
  )
}

export default MuiAvatar; 