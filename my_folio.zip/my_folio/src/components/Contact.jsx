import React from 'react'
import { useState } from "react";


function Contact() {
    const [Contact] = useState([]);
  
        return (
            <section className="contact" id="contact">
            <div className="container">
                <div className="title">
                    <h2>Contact Me</h2>
                </div>
            
            <form>
                <div>
                    <label className="form-label" htmlFor="name">
                        Name
                    </label>
                    <input className="form-control" type="text" id="name" required />
                </div>
                <br></br>
                <div>
                    <label className="form-label" htmlFor="email">
                        Email
                    </label>
                    <input className="form-control" type="email" id="email" required />
                </div>
                <br></br>
                <div>
                    <label className="form-label" htmlFor="message">
                        Message
                    </label>
                    <textarea className="form-control" id="message" required />
                </div>
                <br></br>
                <button className="btn" type="submit">
                    Submit
                </button>
                
            </form>
        </div>
        </section>
        
    );
        }  

export default Contact;