import React from "react";
import { useState } from "react";

function Projects() {
  const [projects] = useState([
    {
      title: "Admin Dashboard",
      img: "/project/admin dashboard.jpg",     
    },
    {
      title: "Clothing Website",
      img: "/project/Cloathing Website.jpg",     
    },
    {
      title: "Financial Website",
      img: "/project/financial website.jpg",
    },
    {
      title: "Minimalistic blog",
      img: "/project/Minimalistic blog.jpg",
    },
    
  ]);
  return (
    <section className="projects" id="projects">
      <div className="container">
        <div className="title">
          <h3>Featured Projects</h3>
        </div>
        <div className="projects-wrapper">
          {projects.map((project, i) => (
            <div className="project" key={i}>
              <div className="img-container">
                <img src={project.img} alt={project.title} />
              </div>
              <div className="description">
                <h4>{project.title}</h4>
              </div>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum
                ea nobis aut deserunt. Reprehenderit numquam harum facilis
                beatae praesentium pariatur eligendi non. Explicabo, cupiditate
                odit vero quo iste numquam obcaecati.
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Projects;
