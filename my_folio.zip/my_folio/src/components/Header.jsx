import React from "react";

import { useState } from "react";

function Header() {
  const [Header] = useState([]);
  

  return (
    <header>
      <div className="header-inner">
        <div className="social"><a href="#">
            <i className="fab fa-facebook"></i>
          </a>
          <a href="#">
            <i className="fab fa-youtube"></i>
          </a>
          <a href="#">
            <i className="fab fa-twitter"></i>
          </a>
          <a href="#">
            <i className="fab fa-linkedin"></i>
          </a>
          <a href="#">
            <i className="fab fa-github"></i>
          </a>
          </div>
        

          
        <div className="links">
          <a className="link" href="#projects">
            Projects
          </a>
          <a className="link" href="#contact">
            Contact Me
          </a>
        </div>
      </div>
    </header>
  );
}

export default Header;
