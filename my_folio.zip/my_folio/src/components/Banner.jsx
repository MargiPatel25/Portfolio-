
import React from "react";

function Banner() {
  return (
    <section className="banner" id="banner">
      <div className="container">
        <div className="banner-wrapper">
          
          <div className="banner-content">
            <h6>Hello I am Margi Patel</h6>
            <br></br>
            <br></br>
            <h3>Frontend Developer</h3>
            <br />
            <h3>Specialised in React</h3>
    
          </div>
        </div>
      </div>
    </section>
  );
}

export default Banner;